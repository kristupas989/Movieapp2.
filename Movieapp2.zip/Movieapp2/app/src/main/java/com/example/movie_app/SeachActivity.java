package com.example.movie_app;

import android.app.Activity;

public class SeachActivity extends Activity {
}
